# OverCrow Creator Kit 1.0.0

Public, dependency-free authoring tools for **Node.js 22+**, Windows and Linux.
SDK **1.3.0**, Web API v1. The code is MIT-licensed. No application source, Rust
compiler, Python, D-Bus or package installation is required by the downloaded kit.

```sh
node overcrow.mjs init my-widget --template counter
cd my-widget
npm run dev
npm run check
npm run package
```

Counter and Checklist support English (default) and French through the SDK locale API. Edit strings in `widget/locales/en.mjs` and `widget/locales/fr.mjs`; `i18n.mjs` applies them to HTML translation keys. The HTML language defaults to `en` and follows runtime locale changes. Use `--template checklist` for persistent state and `--id com.example.widget`
for your own identity. Existing folders are never overwritten. A generated project
ships local tooling and needs no `npm install`. PowerShell users whose policy
blocks npm.ps1 can use `npm.cmd run dev` or `node tooling/overcrow.mjs dev`.

Use `--template blank` for an empty view: only `index.html`, `styles.css`,
`view.js` and `manifest.json`, plus the SDK and its license. No controller,
permissions or sample UI are needed. It follows SDK locale and mode changes;
add translation files when you add text.

Edit `widget/` only for runtime resources. `npm run dev` prints a loopback-only,
random-path preview URL, reloads valid changes and retains the last good generation
on invalid/partial edits. A permission change requires an explicit restart.
The preview includes OverCrow's host wrapper: hover the widget to reveal its
floating toolbar, then open the options menu. Content scale (50–175%, initially
100%) reflows the widget inside its native sizing mode; background opacity (0–100%,
initially 100% for the starter templates) affects the host background and border only. Use the sliders
or type a percentage and press Enter or leave the field. Backgrounds painted by
the widget itself remain unchanged. The eye chooses whether the widget stays visible in passive mode. The Mode selector switches the whole overlay and sends the corresponding SDK snapshot and visibility events; only close is illustrative.
Move the widget
from its 22-pixel top strip. If the widget supports fitting, its native settings include
“Fit to content”: checked fits both axes without a handle, or only the height with a
horizontal handle; unchecked always permits manual resizing in both dimensions.
Creators declare `presentation.sizing.fitToContent` as `false`, `"both"` or `"height"`
and can set `defaultMode` to `"fit"` or `"manual"`. Without a default, supported fitting
starts enabled. `false` requires manual mode. The declaration sets capabilities and
initial defaults; host controls own the user's current choice. Manifest `mode` is no
longer accepted, while SDK snapshots retain `intrinsic`, `autoHeight` and `manual`
to report the effective mode. Content-size reports use unscaled CSS layout pixels; the wrapper applies
scale once. The upper-left corner stays fixed while resizing, within the canvas
bounds. Wrapper controls are hidden in passive mode; use the Mode selector to return to interactive mode. Focus
either control and use arrow keys
(Shift for 10-pixel steps). Appearance, frame size and the user’s fit choice survive same-widget reloads until the preview page itself is refreshed. A changed fitting axis returns to manual; changing widgets applies the new initial defaults. This wrapper belongs to the
host: do not implement it in widget/; it is never included in an exported package.
`overcrow.storage` uses shared, bounded runtime memory and reports `temporary`,
regardless of the persistence permission. Its data resets on preview reload or
a simulated game session change and is never packaged. Native mode uses the
actual OverCrow IndexedDB partition and effective persistence policy.
The simulator restarts both documents on reload. Browser storage is scoped to the
widget and remains separate from OverCrow's native storage.
The preview refresh and drag icons are from Lucide; its license is included in
`preview/lucide-LICENSE.txt` (or `tooling/preview/` inside a project).
Its Storage facade supports getItem/setItem/removeItem/clear/key/length; property
syntax such as localStorage.foo is not simulated. Clipboard gestures are refused
and must be tested in OverCrow. The simulator is not a security or graphics test.

`preview.json` is outside widget/ and never exported. Optional fixtures:

```json
{
  "snapshot": {"running": true, "selectedActive": true, "sessionElapsedMs": 300000},
  "responses": [
    {"url": "https://api.example.com/v2/items", "method": "GET", "status": 200,
     "json": {"data": [{"name": "Example"}]}}
  ]
}
```

Add the corresponding manifest permission. Fixture matching is exact URL/method;
request bodies are not matched. No external API is called or proxied. Missing
fixtures produce `fixture_missing`. Use `text` instead of `json` for plain text.
The preview supplies native snapshot, locale, visibility and controller/view relay
contracts, but does not generate arbitrary named game events or simulate all host
failure modes. Browser devtools remain available for inspecting your widget.

## Widget references

Use `--template session`, `clock`, `performance`, `fps`, `media`, `stopwatch`,
`notes`, `journal`, or `score` for a complete reference with English/French labels
and presentation settings. Every template declares `"apiVersion": "1"`.
Session reads the game context; Clock uses
JavaScript time. Performance, FPS and Media use the host services. Stopwatch uses JavaScript time without persistence.
Notes and Journal keep their own data in isolated `overcrow.storage`. Score uses anonymous `overcrow.fetch` to read the public
PlayerVox score API.

```sh
node overcrow.mjs init my-notes --template notes
```

Public widgets cannot access built-in notes, stopwatch state, journal history or
connected PlayerVox/Twitch accounts. The SDK has no native login, rating editor,
review browser or Twitch integration. Its four service capabilities are
`telemetry.read`, `fps.read`, `media.read` and `media.control`.

The browser preview uses fictional telemetry, FPS and media data. Media controls
change only the fixture; independent widgets update their own temporary storage.
The Score example displays a fictional score in preview and never calls the
public API there. FPS defaults to `unsupported`. Test actual host support, gestures and
permissions in OverCrow before distributing a widget.

Add optional service fixtures outside `widget/` in `preview.json`:

```json
{
  "services": {
    "capabilities": {"fps.read": {"supported": true, "granted": true}},
    "snapshots": {
      "fps": {"status": "stale", "sampleAgeMs": 3000,
        "data": {"value": 60, "sampleAgeMs": 3000, "stale": true}}
    }
  }
}
```

Fixtures cannot grant a capability absent from the manifest. Set `granted:false`
or a service's `permissionDenied`, `unavailable` or `unsupported` status with
`data:null` to exercise fallback UI. `ready` supplies current data; `stale` marks
older data. The simulator owns context IDs
and monotonic revisions. Never put real credentials or private content in
fixtures. Media permissions are sensitive: they cannot be combined with outbound
network or clipboard writes, and they force temporary storage even when
`storage: true` is declared. Artwork is read through `overcrow.assets.read(handle)`
using a media-service handle. See the EN/FR host-services guide and shipped
TypeScript declarations for fields, units and action signatures.

Use `npm run dev -- --native` to run the same project in OverCrow's installed
engine in an offscreen development session. Use `npm run dev` for a visual preview;
native mode does not place the development widget in the overlay. Valid edits reload after a short debounce; invalid or partial
edits leave the last accepted generation running. Expanding permissions or changing
the storage permission (which determines the retained browser context) is refused
until you review them and restart the command. `--devtools` opens native developer
tools, and `--replay ./events.json` replays a bounded schemaVersion 1
event fixture after registration and each accepted reload. The controller stays
alive during view reloads, so restart native mode after changing controller code.

On Windows, native mode launches
`%LOCALAPPDATA%\Programs\OverCrow\OverCrow.exe --widget-development`. On Linux it
resolves `overcrow-widget` from `PATH` and invokes its `dev --watch` command against
a private prepared copy. Portable installations can use
`--host /absolute/path/to/executable`; the path must be absolute. The prepared copy
and generated hash ledger never modify `widget/`. Ctrl+C, SIGTERM, or standard-input
EOF stops the session and cleans up its child process. `doctor --json` only reports
whether the expected native executable is available; it never launches it.

`npm run package` computes manifest hashes and writes a deterministic stored ZIP
`.ocpkg` to `.overcrow-output/`. A digest suffix preserves previous exports. Import
it in the Control Center to test the actual runtime on Windows or Linux. For a
replacement installation, increment version in `widget/manifest.json`; source
package.json is tooling metadata, not the widget version. Nothing is installed,
signed or published automatically. The browser preview remains the default; native
mode requires an existing OverCrow installation.

`check --json` and `package --json` return schemaVersion 1 plus `ok`, diagnostics
and exit status. `doctor --json` reports Node, OS and the available test route.
Authoring checks reject malformed/duplicate JSON keys, unknown manifest fields,
unsafe/nonportable paths, symlinks/junctions, hardlinks, native executables, case
collisions and excessive inputs. The native installer and marketplace validator
remain authoritative. The kit accepts a portable subset of paths to avoid Windows
reserved names; it is not a replacement implementation of the host security model.
Keep API keys and personal fixtures out of widget/.

## Maintainer validation

From the public releases repository root:

```sh
node --test tests/creator-kit/*.test.mjs
python3 scripts/package-docs-examples.py published/docs/downloads
```

The documentation build creates `published/docs/downloads/creator-kit.zip` from
these tools, the documented examples and the SDK downloads. The Windows/Linux CI
matrix exercises the same Node tests. Native package compatibility can additionally
be checked on Linux by extracting an exported archive and running
`overcrow-widget package` against it: output bytes must match exactly. This is
an offline validation, not an application install or native overlay session.

Media grants force temporary browser storage even with `storage` declared.
Runtime or game-session changes discard temporary browser data. Widget storage is
isolated from built-in application data. The browser simulator keeps only fictional
fixtures and does not reproduce the native browser sandbox.
